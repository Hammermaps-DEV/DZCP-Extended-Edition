<?php
/**
 * <DZCP-Extended Edition>
 * @package: DZCP-Extended Edition
 * @author: DZCP Developer Team || Hammermaps.de Developer Team
 * @link: http://www.dzcp.de || http://www.hammermaps.de
 */

define('_version', '1.0');
define('_release', '20.07.2013');
define('_build', 'repo:dev:git:0171');
define('_edition', 'Extended Edition');