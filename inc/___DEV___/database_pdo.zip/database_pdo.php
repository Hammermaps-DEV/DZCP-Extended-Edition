<?php
/**
 * <DZCP-Extended Edition>
 * @package: DZCP-Extended Edition
 * @author: DZCP Developer Team || Hammermaps.de Developer Team
 * @link: http://www.dzcp.de || http://www.hammermaps.de
 */

// #######################################
// ################ CLASS ################
// #######################################
class database_pdo
{
    public static $database_driver = 'mysql'; //mysql,pgsql,sqlsrv
    public static $database_host = 'localhost';
    public static $database_name = '';

    public static $database_login_timeout = '10';
    public static $database_login_user = '';
    public static $database_login_password = '';

    public static $database_connection_encrypting = true;
    public static $database_connection_pooling = true;

    private static $database_dsn_static = array();
    private static $database_pdo_obj_dyn = array();
    private static $database_pdo_obj_stmt = array();
    private static $database_pdo_runned = false;

    public static final function init($remote=false,$driver='',$host='',$name='',$user='',$password='')
    {
        if(!self::$database_pdo_runned)
        {
            DebugConsole::insert_initialize('database_pdo::init()', 'DZCP Database - PDO');
            self::$database_pdo_runned = true;
        }

        $remote = (!$remote ? $remote : 'system');
        if(!self::dsn($remote)) return false;
        self::$database_pdo_obj_dyn[$remote] = new PDO(self::$database_dsn_static[$remote],
        (!empty($user) && $remote != 'system' ? $user : self::$database_login_user),
        ( !empty($password) && $remote != 'system' ? $password : self::$database_login_password));

        return self::$database_pdo_obj_dyn[$remote] != false;
    }

    public static final function query_stmt($statement='INSERT INTO hallo (test1) VALUES (?)',$params=array(array('wert','s')),$fetch=false,$rows=false,$remote=false)
    {
        $remote = (!$remote ? $remote : 'system');
        self::$database_pdo_obj_stmt[$remote] = self::$database_pdo_obj_dyn[$remote]->prepare($statement);

        $i=1;
        foreach ($params as $array) {
            self::$database_pdo_obj_stmt[$remote]->bindValue($i, $array[0], self::getType($array[1]));
            $i++;
        }

        if(self::$database_pdo_obj_stmt[$remote]->execute())
            return false;

        if($rows && $fetch)
            return self::$database_pdo_obj_stmt[$remote]->fetchAll(PDO::FETCH_BOTH);
        else if($fetch)
            return self::$database_pdo_obj_stmt[$remote]->fetchAll(PDO::FETCH_ASSOC);
        else if($rows)
            return self::$database_pdo_obj_stmt[$remote]->rowCount();
        else
            return self::$database_pdo_obj_stmt[$remote]->fetchAll(PDO::FETCH_ASSOC);
    }

    public static final function query($query='INSERT INTO hallo (test1) VALUES (fsdfdsf)',$fetch=false,$rows=false,$remote=false)
    {
        $remote = (!$remote ? $remote : 'system');
        if(self::$database_pdo_obj_stmt[$remote] = self::$database_pdo_obj_dyn[$remote]->query($query))
            return false;

        if($rows && $fetch)
            return self::$database_pdo_obj_stmt[$remote]->fetchAll(PDO::FETCH_BOTH);
        else if($fetch)
            return self::$database_pdo_obj_stmt[$remote]->fetchAll(PDO::FETCH_ASSOC);
        else if($rows)
            return self::$database_pdo_obj_stmt[$remote]->rowCount();
        else
            return self::$database_pdo_obj_stmt[$remote]->fetchAll(PDO::FETCH_ASSOC);
    }

    #####################################
    ############## Private ##############
    #####################################

    /**
     * Gibt den Type zur�ck, der erwartet wird.
     * @param sting $type * b,i,o,s,n
     * @return int
     */
    private static function getType($type)
    {
        switch ($type) {
            case 'b': return PDO::PARAM_BOOL; break; //Bool
            case 'i': return PDO::PARAM_INT; break; //Int
            case 'o': return PDO::PARAM_LOB; break; //Object
            case 'n': return PDO::PARAM_NULL; break; //NULL
            case 's':
            default: return PDO::PARAM_STR; break; //String
        }
    }

    /**
     * Pr�ft ob der n�tige PDO Treiber vorhanden und geladen ist.
     * @return boolean
     */
    private static function check_driver()
    {
        foreach(PDO::getAvailableDrivers() as $driver) {
            if(self::$database_driver == $driver) return true;
        }

        return false;
    }

    /**
     * Setzt die DSN f�r die Datenbank verbindung zusammen
     * @return boolean
     */
    private static function dsn($remote,$driver='')
    {
        if(!self::check_driver())
            return false;

        self::$database_dsn_static[$remote] = sprintf('%s:', self::$database_driver);
        switch(!empty($driver) ? $driver : self::$database_driver)
        {
            case 'mysql':
            case 'pgsql':
                self::$database_dsn_static[$remote] .= sprintf('host=%s;dbname=%s', self::$database_host, self::$database_name);
            break;
            case 'sqlsrv':
                self::$database_dsn_static[$remote] .= sprintf('Server=%s;1433;Database=%s;LoginTimeout=%s', self::$database_host, self::$database_name, self::$database_login_timeout);
                if(self::$database_connection_pooling) self::$database_dsn_static[$remote] .= ';ConnectionPooling=1';
                if(self::$database_connection_encrypting) self::$database_dsn_static[$remote] .= ';Encrypt=1';
            break;
        }

        return true;
    }
}

/*
database_pdo::init();

$params = array();
#$params[] = array('1','i');

$test = database_pdo::query('SELECT * FROM hallo LIMIT 0 , 30',$params,true,false,false);

echo '<pre>';
print_r($test);

die();
*/